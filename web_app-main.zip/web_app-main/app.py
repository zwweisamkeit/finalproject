from flask import Flask, request, render_template
import sqlite3  
from flask_wtf import FlaskForm
from wtforms.validators import DataRequired
from flask_sqlalchemy import SQLAlchemy
from wtforms import *

# Определение формы для добавления фильма
class MyForm(FlaskForm):
    # Поле для названия фильма
    name = StringField('Название', validators=[DataRequired()]) 
    # Поле для года выпуска фильма
    year = IntegerField('Год выпуска', validators=[DataRequired()])
    # Поле для рейтинга фильма
    rating = FloatField('Рейтинг',  validators=[DataRequired()])
    # Поле для жанра фильма
    genre = StringField('Жанр', validators=[DataRequired()])

class MyUserForm(FlaskForm):
    user_firstname=StringField('Имя', validators=[DataRequired()])
    user_lastname=StringField('Фамилия', validators=[DataRequired()])
    age=IntegerField('Возраст', validators=[DataRequired()])
    gender=StringField('Пол', validators=[DataRequired()])

# Инициализация Flask приложения
app = Flask(__name__)

# Настройка соединения с базой данных (sqlite)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///films.db'
db = SQLAlchemy(app)

# Модель фильма для SQLAlchemy
class Film(db.Model):
    __tablename__ = 'Movies'  # Указываем название таблицы

    # Определяем столбцы таблицы
    id = db.Column(db.Integer, primary_key=True)  # ID фильма (первичный ключ)
    name = db.Column(db.String(80))  # Название фильма
    year = db.Column(db.Integer)  # Год выпуска фильма
    rating = db.Column(db.Float)  # Рейтинг фильма
    genre = db.Column(db.String(80))  # Жанр фильма

    # Конструктор для создания нового объекта Film
    def __init__(self, name, year, rating, genre):
        self.name = name
        self.year = year
        self.rating = rating
        self.genre = genre

class User(db.Model):
    __tablename__ = 'users'  # Указываем название таблицы

    # Определяем столбцы таблицы
    user_id = db.Column(db.Integer, primary_key=True)  # ID пользователя (первичный ключ)
    user_firstname = db.Column(db.String(80))  # имя
    user_lastname = db.Column(db.String(80))  # фамилия
    age = db.Column(db.Integer)  # возраст
    gender = db.Column(db.String(80))  # пол

    # Конструктор для создания нового объекта User
    def __init__(self, user_firstname, user_lastname, age, gender):
        self.user_firstname = user_firstname
        self.user_lastname = user_lastname
        self.age = age
        self.gender = gender

# Создание соединения с базой данных  
con = sqlite3.connect('./instance/films.db', check_same_thread=False)
# Создание курсора для выполнения SQL запросов  
cur = con.cursor()

# Маршрут для корневой страницы
@app.route("/")
def hello_world():
    # Возвращение приветственного сообщения
    return render_template('main.html')

# Маршрут для получения информации о фильме по ID
@app.route("/film/<id>")
def film(id):
    film = Film.query.filter_by(id=id).all()
    print(film)
    # Проверка, найден ли фильм
    if film != []:
        # Возвращение результата
        return render_template('film.html', film = film[0] )
    else:
        # Сообщение о том, что фильма не существует 
        return "Такого фильма нет"

# Маршрут для получения информации о пользователе по ID
@app.route("/user/<user_id>")
def user(user_id):
    user = User.query.filter_by(user_id=user_id).all()
    print(user)
    # Проверка, найден ли пользователь
    if user != []:
        # Возвращение результата
        return render_template('user.html', user = user[0] )
    else:
        # Сообщение о том, что пользователя не существует 
        return "Такого пользователя нет"

# Маршрут для получения списка всех фильмов
@app.route("/films" )
def films():
    films = Film.query.all()
    # Возвращение списка фильмов
    return render_template('films.html', films = films)

# Маршрут для получения списка всех пользователей
@app.route("/users" )
def users():
    users = User.query.all()
    # Возвращение списка пользователей
    return render_template('users.html', users = users)

# Маршрут для отображения формы добавления фильма
@app.route("/film_form", methods=['GET', 'POST'])
def film_form():
    # Создание формы
    form = MyForm()
    # Проверка, была ли отправлена заполненная форма на сервер
    if form.validate_on_submit():
        # Извлекаем данные из формы
        name=form.data['name']
        year=form.data['year']
        rating=form.data['rating']
        genre=form.data['genre']
        #Создаем объект фильма
        new_film = Film(name, year, rating, genre)
        #Добавляем в БД
        db.session.add(new_film)
        #Фиксируем изменения
        db.session.commit()
        return render_template('back.html')
    # Возвращаем форму для отображения к заполнению
    return render_template('form.html', form=form)

# Маршрут для отображения формы добавления пользователя
@app.route("/user_form", methods=['GET', 'POST'])
def user_form():
    # Создание формы
    user = MyUserForm()
    # Проверка, была ли отправлена заполненная форма на сервер
    if user.validate_on_submit():
        # Извлекаем данные из формы
        user_firstname=user.data['user_firstname']
        user_lastname=user.data['user_lastname']
        age=user.data['age']
        gender=user.data['gender']
        #Создаем объект пользователя
        new_user = User(user_firstname, user_lastname, age, gender)
        #Добавляем в БД
        db.session.add(new_user)
        #Фиксируем изменения
        db.session.commit()
        return render_template('back copy.html')
    # Возвращаем форму для отображения к заполнению
    return render_template('form copy.html', user=user)

# Запуск приложения, если оно выполняется как главный модуль
if __name__ == '__main__':
    # Отключение проверки CSRF для WTForms
    app.config["WTF_CSRF_ENABLED"] = False  
    # Запуск приложения в режиме отладки
    app.run(debug=True)
